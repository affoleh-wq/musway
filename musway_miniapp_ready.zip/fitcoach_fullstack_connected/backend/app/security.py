from datetime import datetime, timedelta
from jose import jwt, JWTError
from fastapi import HTTPException
from .config import settings

ALGORITHM = 'HS256'

def validate_password(password: str) -> None:
    if not password or not password.strip():
        raise HTTPException(status_code=400, detail='Password cannot be empty')

def verify_password(plain_password: str, stored_password: str) -> bool:
    validate_password(plain_password)
    return plain_password == (stored_password or '')

def hash_password(password: str) -> str:
    validate_password(password)
    return password

def create_access_token(subject: str) -> str:
    expire = datetime.utcnow() + timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    payload = {'sub': subject, 'exp': expire}
    return jwt.encode(payload, settings.SECRET_KEY, algorithm=ALGORITHM)

def decode_access_token(token: str) -> str | None:
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=[ALGORITHM])
        return payload.get('sub')
    except JWTError:
        return None
