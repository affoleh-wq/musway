from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.db import Base, engine
from app.routers import auth, profile, weight, food, workout, nutrition, coach, analytics, notifications

Base.metadata.create_all(bind=engine)

app = FastAPI(title='FitCoach API')

app.add_middleware(
    CORSMiddleware,
    allow_origins=['*'],
    allow_credentials=True,
    allow_methods=['*'],
    allow_headers=['*'],
)

app.include_router(auth.router, prefix='/api/auth', tags=['auth'])
app.include_router(profile.router, prefix='/api/profile', tags=['profile'])
app.include_router(weight.router, prefix='/api/weight', tags=['weight'])
app.include_router(food.router, prefix='/api/food', tags=['food'])
app.include_router(workout.router, prefix='/api/workout', tags=['workout'])
app.include_router(nutrition.router, prefix='/api/nutrition', tags=['nutrition'])
app.include_router(coach.router, prefix='/api/coach', tags=['coach'])
app.include_router(analytics.router, prefix='/api/analytics', tags=['analytics'])
app.include_router(notifications.router, prefix='/api/notifications', tags=['notifications'])


@app.get('/')
def root():
    return {'name': 'FitCoach API', 'status': 'ok'}
