from datetime import datetime
from sqlalchemy import Column, Integer, String, Float, Boolean, DateTime, ForeignKey, Text
from sqlalchemy.orm import relationship
from .db import Base


class User(Base):
    __tablename__ = 'users'

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String(255), unique=True, index=True, nullable=True)
    password_hash = Column(String(255), nullable=True)
    telegram_id = Column(String(64), unique=True, nullable=True, index=True)
    telegram_connect_code = Column(String(64), nullable=True, index=True)
    telegram_connected = Column(Boolean, default=False)

    name = Column(String(255), nullable=True)
    goal = Column(String(255), nullable=True)
    weight = Column(Float, nullable=True)
    height = Column(Float, nullable=True)
    age = Column(Integer, nullable=True)
    gender = Column(String(20), nullable=True)
    activity_level = Column(String(20), nullable=True)
    allergies = Column(Text, nullable=True)
    excluded_foods = Column(Text, nullable=True)
    meals_per_day = Column(Integer, nullable=True)
    daily_calorie_goal = Column(Integer, nullable=True)
    weight_goal = Column(Float, nullable=True)

    notifications_enabled = Column(Boolean, default=True)
    water_notifications = Column(Boolean, default=True)
    meal_notifications = Column(Boolean, default=True)
    workout_notifications = Column(Boolean, default=True)
    water_time = Column(String(5), default='10:00')
    meal_time = Column(String(5), default='13:00')
    workout_time = Column(String(5), default='18:00')

    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    workouts = relationship('Workout', back_populates='user', cascade='all, delete-orphan')
    nutritions = relationship('Nutrition', back_populates='user', cascade='all, delete-orphan')
    food_logs = relationship('FoodLog', back_populates='user', cascade='all, delete-orphan')
    weight_logs = relationship('WeightLog', back_populates='user', cascade='all, delete-orphan')


class Workout(Base):
    __tablename__ = 'workouts'

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    text = Column(Text, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    user = relationship('User', back_populates='workouts')


class Nutrition(Base):
    __tablename__ = 'nutritions'

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    text = Column(Text, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    user = relationship('User', back_populates='nutritions')


class FoodLog(Base):
    __tablename__ = 'food_logs'

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    text = Column(Text, nullable=False)
    calories = Column(Integer, default=0)
    protein = Column(Integer, default=0)
    fat = Column(Integer, default=0)
    carbs = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)
    user = relationship('User', back_populates='food_logs')


class WeightLog(Base):
    __tablename__ = 'weight_logs'

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    weight = Column(Float, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    user = relationship('User', back_populates='weight_logs')
