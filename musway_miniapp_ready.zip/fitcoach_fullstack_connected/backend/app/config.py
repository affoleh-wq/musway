import os
from dotenv import load_dotenv

load_dotenv()

class Settings:
    APP_NAME = 'FitCoach API'
    DATABASE_URL = os.getenv('DATABASE_URL', 'sqlite:///./fitcoach.db')
    OPENAI_API_KEY = os.getenv('OPENAI_API_KEY', '')
    SECRET_KEY = os.getenv('SECRET_KEY', 'change-me-super-secret')
    ACCESS_TOKEN_EXPIRE_MINUTES = int(os.getenv('ACCESS_TOKEN_EXPIRE_MINUTES', '10080'))
    APP_BASE_URL = os.getenv('APP_BASE_URL', 'http://127.0.0.1:8000')

settings = Settings()
