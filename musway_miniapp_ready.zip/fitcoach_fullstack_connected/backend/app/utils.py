import random
import re
from datetime import datetime, timedelta
from openai import OpenAI
from .config import settings

client = OpenAI(api_key=settings.OPENAI_API_KEY) if settings.OPENAI_API_KEY else None
QUICK_FOOD_MAP = {
    'chicken': 'куриная грудка 200 грамм',
    'rice': 'рис отварной 150 грамм',
    'apple': 'яблоко среднее 1 штука',
    'eggs': 'два куриных яйца',
    'yogurt': 'йогурт натуральный 1 порция',
    'nuts': 'орехи 30 грамм',
}


def calculate_smart_calories(user) -> int:
    if not all([user.weight, user.height, user.age]):
        return 0
    if user.gender == 'female':
        bmr = 10 * user.weight + 6.25 * user.height - 5 * user.age - 161
    else:
        bmr = 10 * user.weight + 6.25 * user.height - 5 * user.age + 5
    activity_map = {'low': 1.2, 'medium': 1.55, 'high': 1.725}
    calories = bmr * activity_map.get(user.activity_level, 1.4)
    goal = (user.goal or '').lower()
    if 'похуд' in goal:
        calories *= 0.8
    elif 'набор' in goal or 'мас' in goal:
        calories *= 1.15
    return int(calories)


def ai_text_response(system_text: str, user_prompt: str, fallback: str) -> str:
    if not client:
        return fallback
    response = client.chat.completions.create(
        model='gpt-4.1-mini',
        messages=[
            {'role': 'system', 'content': system_text},
            {'role': 'user', 'content': user_prompt},
        ],
        temperature=0.5,
    )
    return response.choices[0].message.content.strip()


def generate_ai_workout(user) -> str:
    prompt = f"""Сделай короткую тренировку на русском языке для цели: {user.goal}. Вес {user.weight}, рост {user.height}, возраст {user.age}. Формат: заголовок, 5 упражнений, совет."""
    fallback = (
        f"🏋️ Тренировка ({user.goal or 'цель'})\n\n"
        "1. Приседания — 3x12\n"
        "2. Отжимания — 3x10\n"
        "3. Выпады — 3x12\n"
        "4. Планка — 3x30 сек\n"
        "5. Скручивания — 3x15\n\n"
        "⚡ Совет: держи умеренный темп и следи за техникой."
    )
    return ai_text_response('Ты краткий фитнес-тренер.', prompt, fallback)


def generate_ai_nutrition(user) -> str:
    prompt = f"""Сделай краткий план питания на 1 день на русском языке. Цель: {user.goal}. Аллергии: {user.allergies}. Исключить: {user.excluded_foods}. Приемов пищи: {user.meals_per_day}."""
    meals = user.meals_per_day or 4
    lines = [
        f"🥗 Питание ({user.goal or 'цель'})",
        '',
        '🍳 Завтрак: омлет и овощи',
        '🍎 Перекус: йогурт или яблоко',
        '🍗 Обед: курица, рис, салат',
    ]
    if meals >= 4:
        lines.append('🥛 Перекус: орехи или творог')
    lines.append('🐟 Ужин: рыба и овощи')
    lines.append('💧 Вода: 2-2.5 л')
    fallback = '\n'.join(lines)
    return ai_text_response('Ты краткий нутрициолог.', prompt, fallback)


def generate_week_plan(user) -> str:
    fallback = """📆 План на неделю

Понедельник:
🏋️ Силовая тренировка
🥗 Курица и овощи

Вторник:
🏃 Ходьба 40 минут
🥗 Рыба и рис

Среда:
🏋️ Тренировка на всё тело
🥗 Омлет и салат

Четверг:
🚶 Активное восстановление
🥗 Творог и фрукты

Пятница:
🏋️ Ноги и корпус
🥗 Индейка и гречка

Суббота:
🚴 Кардио 30 минут
🥗 Йогурт, орехи, овощи

Воскресенье:
🧘 Растяжка и отдых
🥗 Легкий белковый ужин"""
    return ai_text_response('Ты полезный фитнес-ассистент.', f'Составь недельный план для цели {user.goal}', fallback)


def _estimate_macros_from_text(food_text: str) -> dict:
    text = food_text.lower()
    presets = [
        ('кур', ('Куриная грудка', 330, 62, 7, 0)),
        ('рис', ('Рис', 180, 4, 1, 39)),
        ('яблок', ('Яблоко', 95, 0, 0, 25)),
        ('яйц', ('Яйца', 160, 12, 11, 1)),
        ('йогур', ('Йогурт', 120, 8, 4, 12)),
        ('орех', ('Орехи', 180, 5, 15, 6)),
    ]
    for key, values in presets:
        if key in text:
            d, c, p, f, cb = values
            return {'description': d, 'calories': c, 'protein': p, 'fat': f, 'carbs': cb, 'confidence': 80}
    return {'description': food_text, 'calories': 250, 'protein': 15, 'fat': 10, 'carbs': 20, 'confidence': 65}


def analyze_food_with_ai(food_text: str) -> dict:
    if not client:
        return _estimate_macros_from_text(food_text)
    prompt = f"Оцени примерные КБЖУ для: {food_text}. Ответ в формате: Описание, Калории, Белки, Жиры, Углеводы, Уверенность"
    text = ai_text_response('Ты оцениваешь еду и считаешь примерные КБЖУ.', prompt, '')
    return parse_macros(text) if text else _estimate_macros_from_text(food_text)


def parse_macros(text: str):
    description = re.search(r'Описание:\s*(.+)', text)
    calories = re.search(r'Калории:\s*(\d+)', text)
    protein = re.search(r'Белки:\s*(\d+)', text)
    fat = re.search(r'Жиры:\s*(\d+)', text)
    carbs = re.search(r'Углеводы:\s*(\d+)', text)
    confidence = re.search(r'Уверенность:\s*(\d+)', text)
    return {
        'description': description.group(1).strip() if description else 'Еда',
        'calories': int(calories.group(1)) if calories else 0,
        'protein': int(protein.group(1)) if protein else 0,
        'fat': int(fat.group(1)) if fat else 0,
        'carbs': int(carbs.group(1)) if carbs else 0,
        'confidence': int(confidence.group(1)) if confidence else 75,
    }


def coach_answer(user, today_calories: int, message: str) -> str:
    fallback = (
        f"Ты на цели: {user.goal or 'без цели'}; сегодня уже {today_calories} ккал. "
        "Держись простоты: белок + овощи + вода. Если тяжело — сделай маленький шаг сегодня, не идеальный."
    )
    return ai_text_response('Ты поддерживающий и практичный фитнес-коуч.', message, fallback)


def progress_summary(user, logs) -> str:
    if len(logs) < 2:
        return 'Пока мало данных для анализа. Добавь ещё несколько замеров веса.'
    start_weight = logs[0].weight
    current_weight = logs[-1].weight
    diff = current_weight - start_weight
    trend = 'вниз' if diff < 0 else 'вверх' if diff > 0 else 'без изменений'
    return f'Старт: {start_weight} кг, сейчас: {current_weight} кг, динамика: {trend} ({diff:+.1f} кг).'


def generate_connect_code() -> str:
    return f'FC-{random.randint(100000, 999999)}'
