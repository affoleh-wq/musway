from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.db import get_db
from app.deps import get_current_user
from app.models import User, Nutrition
from app.utils import generate_ai_nutrition, generate_week_plan

router = APIRouter()


@router.post('/generate')
def generate_nutrition(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    text = generate_ai_nutrition(user)
    item = Nutrition(user_id=user.id, text=text)
    db.add(item)
    db.commit()
    return {'text': text}


@router.get('/latest')
def latest_nutrition(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    item = db.query(Nutrition).filter(Nutrition.user_id == user.id).order_by(Nutrition.created_at.desc()).first()
    return {'text': item.text if item else ''}


@router.get('/week-plan')
def week_plan(user: User = Depends(get_current_user)):
    return {'text': generate_week_plan(user)}
