from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.db import get_db
from app.deps import get_current_user
from app.models import User, WeightLog
from app.schemas import WeightAddRequest, ProgressResponse
from app.utils import calculate_smart_calories, progress_summary

router = APIRouter()


@router.post('')
def add_weight(payload: WeightAddRequest, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    user.weight = payload.weight
    if user.height and user.age and user.gender and user.activity_level:
        user.daily_calorie_goal = calculate_smart_calories(user)
    db.add(WeightLog(user_id=user.id, weight=payload.weight))
    db.commit()
    return {'ok': True, 'weight': payload.weight, 'daily_calorie_goal': user.daily_calorie_goal}


@router.get('/history')
def weight_history(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    logs = db.query(WeightLog).filter(WeightLog.user_id == user.id).order_by(WeightLog.created_at.asc()).all()
    return [{'weight': x.weight, 'created_at': x.created_at.isoformat()} for x in logs]


@router.get('/progress', response_model=ProgressResponse)
def weight_progress(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    logs = db.query(WeightLog).filter(WeightLog.user_id == user.id).order_by(WeightLog.created_at.asc()).all()
    if logs:
        start_weight = logs[0].weight
        current_weight = logs[-1].weight
        difference = current_weight - start_weight
    else:
        start_weight = current_weight = difference = None
    progress_percent = None
    if user.weight_goal is not None and logs:
        total = abs(start_weight - user.weight_goal)
        current_path = abs(current_weight - user.weight_goal)
        progress_percent = 100 if total == 0 else max(0, min(100, int((1 - current_path / total) * 100)))
    return ProgressResponse(
        start_weight=start_weight,
        current_weight=current_weight,
        difference=difference,
        progress_percent=progress_percent,
        weight_logs=logs,
        ai_summary=progress_summary(user, logs),
    )
