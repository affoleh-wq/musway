from datetime import datetime
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.db import get_db
from app.deps import get_current_user
from app.models import User, FoodLog
from app.schemas import CoachRequest, CoachResponse
from app.utils import coach_answer

router = APIRouter()


@router.post('/message', response_model=CoachResponse)
def message(payload: CoachRequest, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    today_start = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
    logs = db.query(FoodLog).filter(FoodLog.user_id == user.id, FoodLog.created_at >= today_start).all()
    total_calories = sum(x.calories or 0 for x in logs)
    return CoachResponse(answer=coach_answer(user, total_calories, payload.message))
