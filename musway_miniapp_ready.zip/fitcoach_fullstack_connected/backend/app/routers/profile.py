from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.db import get_db
from app.deps import get_current_user
from app.models import User, WeightLog
from app.schemas import ProfileResponse, ProfileUpdate
from app.utils import calculate_smart_calories

router = APIRouter()


@router.get('', response_model=ProfileResponse)
def get_profile(user: User = Depends(get_current_user)):
    return user


@router.put('', response_model=ProfileResponse)
def update_profile(payload: ProfileUpdate, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(user, field, value)
    if user.weight and user.height and user.age and user.gender and user.activity_level:
        user.daily_calorie_goal = payload.daily_calorie_goal or calculate_smart_calories(user)
    if user.weight and not db.query(WeightLog).filter(WeightLog.user_id == user.id).first():
        db.add(WeightLog(user_id=user.id, weight=user.weight))
    db.commit()
    db.refresh(user)
    return user
