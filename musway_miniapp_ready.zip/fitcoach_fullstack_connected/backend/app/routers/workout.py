from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.db import get_db
from app.deps import get_current_user
from app.models import User, Workout
from app.utils import generate_ai_workout

router = APIRouter()


@router.post('/generate')
def generate_workout(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    text = generate_ai_workout(user)
    workout = Workout(user_id=user.id, text=text)
    db.add(workout)
    db.commit()
    return {'text': text}


@router.get('/latest')
def latest_workout(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    workout = db.query(Workout).filter(Workout.user_id == user.id).order_by(Workout.created_at.desc()).first()
    return {'text': workout.text if workout else ''}
