from datetime import datetime, timedelta
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.db import get_db
from app.deps import get_current_user
from app.models import User, FoodLog

router = APIRouter()


@router.get('/weekly')
def weekly(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    start_date = datetime.utcnow() - timedelta(days=6)
    logs = db.query(FoodLog).filter(FoodLog.user_id == user.id, FoodLog.created_at >= start_date).all()
    if not logs:
        return {'days': 0, 'avg_calories': 0, 'avg_protein': 0, 'avg_fat': 0, 'avg_carbs': 0, 'message': 'Пока мало данных по питанию.'}
    days = max(1, len({x.created_at.strftime('%Y-%m-%d') for x in logs}))
    return {
        'days': days,
        'avg_calories': int(sum(x.calories or 0 for x in logs) / days),
        'avg_protein': int(sum(x.protein or 0 for x in logs) / days),
        'avg_fat': int(sum(x.fat or 0 for x in logs) / days),
        'avg_carbs': int(sum(x.carbs or 0 for x in logs) / days),
        'message': 'Сравни средние значения с целью по калориям и следи за белком.'
    }
