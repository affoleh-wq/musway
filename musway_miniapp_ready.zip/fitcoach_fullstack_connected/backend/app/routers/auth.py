from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.db import get_db
from app.models import User
from app.schemas import RegisterRequest, LoginRequest, TokenResponse, TelegramCodeResponse, TelegramConnectRequest, ProfileResponse
from app.security import hash_password, verify_password, create_access_token
from app.deps import get_current_user
from app.utils import generate_connect_code

router = APIRouter()


@router.post('/start', response_model=TokenResponse)
def start(db: Session = Depends(get_db)):
    user = User()
    db.add(user)
    db.commit()
    db.refresh(user)
    return TokenResponse(access_token=create_access_token(str(user.id)))


@router.post('/register', response_model=TokenResponse)
def register(payload: RegisterRequest, db: Session = Depends(get_db)):
    email = str(payload.email).strip().lower()
    exists = db.query(User).filter(User.email == email).first()
    if exists:
        raise HTTPException(status_code=400, detail='Email already registered')
    user = User(email=email, password_hash=hash_password(payload.password), name=(payload.name or '').strip() or None)
    db.add(user)
    db.commit()
    db.refresh(user)
    return TokenResponse(access_token=create_access_token(str(user.id)))


@router.post('/login', response_model=TokenResponse)
def login(payload: LoginRequest, db: Session = Depends(get_db)):
    email = str(payload.email).strip().lower()
    user = db.query(User).filter(User.email == email).first()
    if not user or not verify_password(payload.password, user.password_hash or ''):
        raise HTTPException(status_code=401, detail='Invalid credentials')
    return TokenResponse(access_token=create_access_token(str(user.id)))


@router.get('/me', response_model=ProfileResponse)
def me(user: User = Depends(get_current_user)):
    return user


@router.post('/generate-telegram-code', response_model=TelegramCodeResponse)
def generate_telegram_code(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    user.telegram_connect_code = generate_connect_code()
    db.commit()
    return TelegramCodeResponse(code=user.telegram_connect_code)


@router.post('/connect-telegram')
def connect_telegram(payload: TelegramConnectRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.telegram_connect_code == payload.code).first()
    if not user:
        raise HTTPException(status_code=404, detail='Code not found')
    user.telegram_id = payload.telegram_id
    user.telegram_connected = True
    user.telegram_connect_code = None
    db.commit()
    return {'ok': True, 'message': 'Telegram connected'}
