from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.db import get_db
from app.deps import get_current_user
from app.models import User
from app.schemas import NotificationsUpdate

router = APIRouter()


@router.get('')
def get_notifications(user: User = Depends(get_current_user)):
    return {
        'notifications_enabled': user.notifications_enabled,
        'water_notifications': user.water_notifications,
        'meal_notifications': user.meal_notifications,
        'workout_notifications': user.workout_notifications,
        'water_time': user.water_time,
        'meal_time': user.meal_time,
        'workout_time': user.workout_time,
    }


@router.put('')
def update_notifications(payload: NotificationsUpdate, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(user, field, value)
    db.commit()
    return {'ok': True}
