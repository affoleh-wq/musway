from datetime import datetime, timedelta
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.db import get_db
from app.deps import get_current_user
from app.models import User, FoodLog
from app.schemas import FoodAddRequest, FoodQuickAddRequest, DailySummary
from app.utils import analyze_food_with_ai, QUICK_FOOD_MAP

router = APIRouter()


def _daily_summary(user: User, logs: list[FoodLog]) -> DailySummary:
    total_calories = sum(x.calories or 0 for x in logs)
    total_protein = sum(x.protein or 0 for x in logs)
    total_fat = sum(x.fat or 0 for x in logs)
    total_carbs = sum(x.carbs or 0 for x in logs)
    remaining = (user.daily_calorie_goal - total_calories) if user.daily_calorie_goal else None
    return DailySummary(
        entries=logs,
        total_calories=total_calories,
        total_protein=total_protein,
        total_fat=total_fat,
        total_carbs=total_carbs,
        remaining_calories=remaining,
    )


@router.post('/add')
def add_food(payload: FoodAddRequest, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    macros = analyze_food_with_ai(payload.text)
    log = FoodLog(user_id=user.id, text=macros['description'], calories=macros['calories'], protein=macros['protein'], fat=macros['fat'], carbs=macros['carbs'])
    db.add(log)
    db.commit()
    db.refresh(log)
    return {'ok': True, 'entry': log, 'confidence': macros['confidence']}


@router.post('/quick-add')
def quick_add(payload: FoodQuickAddRequest, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    if payload.key not in QUICK_FOOD_MAP:
        raise HTTPException(status_code=400, detail='Unknown quick food key')
    macros = analyze_food_with_ai(QUICK_FOOD_MAP[payload.key])
    log = FoodLog(user_id=user.id, text=macros['description'], calories=macros['calories'], protein=macros['protein'], fat=macros['fat'], carbs=macros['carbs'])
    db.add(log)
    db.commit()
    db.refresh(log)
    return {'ok': True, 'entry': log}


@router.get('/today', response_model=DailySummary)
def today_food(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    today_start = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
    logs = db.query(FoodLog).filter(FoodLog.user_id == user.id, FoodLog.created_at >= today_start).order_by(FoodLog.created_at.asc()).all()
    return _daily_summary(user, logs)


@router.get('/history')
def food_history(days: int = 7, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    start_date = datetime.utcnow() - timedelta(days=max(1, min(days, 30)) - 1)
    logs = db.query(FoodLog).filter(FoodLog.user_id == user.id, FoodLog.created_at >= start_date).order_by(FoodLog.created_at.asc()).all()
    return logs


@router.delete('/last')
def delete_last(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    last = db.query(FoodLog).filter(FoodLog.user_id == user.id).order_by(FoodLog.created_at.desc()).first()
    if not last:
        raise HTTPException(status_code=404, detail='No food entries')
    deleted = last.text
    db.delete(last)
    db.commit()
    return {'ok': True, 'deleted': deleted}
