from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel, EmailStr


class RegisterRequest(BaseModel):
    email: EmailStr
    password: str
    name: Optional[str] = None


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = 'bearer'


class ProfileUpdate(BaseModel):
    name: Optional[str] = None
    goal: Optional[str] = None
    weight: Optional[float] = None
    height: Optional[float] = None
    age: Optional[int] = None
    gender: Optional[str] = None
    activity_level: Optional[str] = None
    allergies: Optional[str] = None
    excluded_foods: Optional[str] = None
    meals_per_day: Optional[int] = None
    weight_goal: Optional[float] = None
    daily_calorie_goal: Optional[int] = None


class ProfileResponse(BaseModel):
    id: int
    email: Optional[str]
    telegram_connected: bool
    name: Optional[str]
    goal: Optional[str]
    weight: Optional[float]
    height: Optional[float]
    age: Optional[int]
    gender: Optional[str]
    activity_level: Optional[str]
    allergies: Optional[str]
    excluded_foods: Optional[str]
    meals_per_day: Optional[int]
    daily_calorie_goal: Optional[int]
    weight_goal: Optional[float]

    class Config:
        from_attributes = True


class WeightAddRequest(BaseModel):
    weight: float


class WeightLogItem(BaseModel):
    weight: float
    created_at: datetime

    class Config:
        from_attributes = True


class FoodAddRequest(BaseModel):
    text: str


class FoodQuickAddRequest(BaseModel):
    key: str


class FoodLogResponse(BaseModel):
    id: int
    text: str
    calories: int
    protein: int
    fat: int
    carbs: int
    created_at: datetime

    class Config:
        from_attributes = True


class WorkoutResponse(BaseModel):
    text: str


class NutritionResponse(BaseModel):
    text: str


class CoachRequest(BaseModel):
    message: str


class CoachResponse(BaseModel):
    answer: str


class TelegramCodeResponse(BaseModel):
    code: str


class TelegramConnectRequest(BaseModel):
    code: str
    telegram_id: str


class NotificationsUpdate(BaseModel):
    notifications_enabled: Optional[bool] = None
    water_notifications: Optional[bool] = None
    meal_notifications: Optional[bool] = None
    workout_notifications: Optional[bool] = None
    water_time: Optional[str] = None
    meal_time: Optional[str] = None
    workout_time: Optional[str] = None


class DailySummary(BaseModel):
    entries: List[FoodLogResponse]
    total_calories: int
    total_protein: int
    total_fat: int
    total_carbs: int
    remaining_calories: Optional[int] = None


class ProgressResponse(BaseModel):
    start_weight: Optional[float]
    current_weight: Optional[float]
    difference: Optional[float]
    progress_percent: Optional[int]
    weight_logs: List[WeightLogItem]
    ai_summary: str
