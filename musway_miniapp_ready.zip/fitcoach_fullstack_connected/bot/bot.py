import os
import asyncio
from urllib.parse import urlparse

from dotenv import load_dotenv
from aiogram import Bot, Dispatcher, F
from aiogram.filters import Command
from aiogram.types import (
    Message,
    InlineKeyboardMarkup,
    InlineKeyboardButton,
    WebAppInfo,
)

load_dotenv()
BOT_TOKEN = os.getenv('BOT_TOKEN')
WEB_APP_URL = os.getenv('WEB_APP_URL', '').strip()
APP_NAME = os.getenv('APP_NAME', 'MUSWAY').strip() or 'MUSWAY'

if not BOT_TOKEN:
    raise RuntimeError('BOT_TOKEN is missing')

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher()


def normalize_web_app_url(value: str) -> str:
    if not value:
        return ''
    value = value.strip()
    parsed = urlparse(value)
    if parsed.scheme not in {'https', 'http'}:
        raise RuntimeError('WEB_APP_URL must start with https:// or http://')
    return value


WEB_APP_URL = normalize_web_app_url(WEB_APP_URL)


def app_keyboard() -> InlineKeyboardMarkup | None:
    if not WEB_APP_URL:
        return None
    return InlineKeyboardMarkup(
        inline_keyboard=[[
            InlineKeyboardButton(
                text=f'Открыть {APP_NAME}',
                web_app=WebAppInfo(url=WEB_APP_URL),
            )
        ]]
    )


HELP_TEXT = (
    f'Привет! Это бот mini app {APP_NAME}.\n\n'
    'Что делать дальше:\n'
    '1. Нажми кнопку ниже.\n'
    '2. Откроется приложение внутри Telegram.\n'
    '3. Пройди онбординг и пользуйся дашбордом.\n\n'
    'Команды:\n'
    '/start — показать кнопку открытия\n'
    '/app — открыть mini app\n'
    '/help — помощь'
)


@dp.message(Command('start'))
async def start(message: Message):
    if not WEB_APP_URL:
        await message.answer(
            'Бот запущен, но WEB_APP_URL пока не настроен. '\
            'Добавь адрес фронтенда в bot/.env и перезапусти бота.\n\n'
            'Пример:\nWEB_APP_URL=https://your-domain.com/auth?tg=1'
        )
        return

    await message.answer(
        HELP_TEXT,
        reply_markup=app_keyboard(),
    )


@dp.message(Command('app'))
async def open_app(message: Message):
    if not WEB_APP_URL:
        await message.answer('WEB_APP_URL не заполнен в bot/.env')
        return

    await message.answer(
        f'Открывай {APP_NAME} 👇',
        reply_markup=app_keyboard(),
    )


@dp.message(Command('help'))
async def help_cmd(message: Message):
    await start(message)


@dp.message(F.text)
async def fallback(message: Message):
    if WEB_APP_URL:
        await message.answer(
            f'Нажми кнопку, чтобы открыть {APP_NAME} внутри Telegram.',
            reply_markup=app_keyboard(),
        )
    else:
        await message.answer('Бот запущен, но WEB_APP_URL пока не настроен в bot/.env')


if __name__ == '__main__':
    asyncio.run(dp.start_polling(bot))
