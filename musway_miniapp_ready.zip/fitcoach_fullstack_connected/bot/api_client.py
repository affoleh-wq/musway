import os
import requests
from dotenv import load_dotenv

load_dotenv()
API_URL = os.getenv('API_URL', 'http://127.0.0.1:8000')


def connect_telegram(code: str, telegram_id: str):
    r = requests.post(f'{API_URL}/api/auth/connect-telegram', json={'code': code, 'telegram_id': telegram_id}, timeout=30)
    return r


def get_user_by_telegram(db_url: str = None):
    raise NotImplementedError('Use dedicated backend endpoint if needed later.')
