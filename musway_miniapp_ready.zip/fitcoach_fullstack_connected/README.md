# FitCoach fullstack connected

## Что внутри
- `backend/` — FastAPI API
- `frontend/` — Lovable/Vite frontend, уже подключённый к backend
- `bot/` — Telegram bot starter

## Быстрый запуск

### 1) Backend
```bash
cd backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload
```

Если у тебя Python 3.14 и bcrypt снова капризничает — в этом архиве auth уже упрощён и не использует bcrypt.

### 2) Frontend
```bash
cd frontend
npm install
cp .env.example .env
npm run dev
```

Frontend ждёт backend по `http://127.0.0.1:8000`.

### 3) Вход
Открой frontend и перейди на `/auth`.

Тестовые поля уже предзаполнены:
- email: `oleg@test.com`
- password: `12345678`

Сначала нажми регистрацию, потом вход.

## Что уже подключено
- auth
- профиль
- дневник питания
- генерация тренировки
- генерация питания
- коуч
- план недели
- уведомления
- прогресс
- базовая аналитика

## Замечание
Графики и некоторые страницы используют смесь реальных данных backend и упрощённого UI. Это рабочий стартовый fullstack, который можно дальше допиливать.
