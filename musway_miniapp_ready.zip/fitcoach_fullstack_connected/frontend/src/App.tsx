import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Landing from "./pages/Landing";
import AuthPage from "./pages/AuthPage";
import AppLayout from "./components/AppLayout";
import Dashboard from "./pages/app/Dashboard";
import ProfilePage from "./pages/app/ProfilePage";
import WorkoutsPage from "./pages/app/WorkoutsPage";
import NutritionPage from "./pages/app/NutritionPage";
import DiaryPage from "./pages/app/DiaryPage";
import ProgressPage from "./pages/app/ProgressPage";
import AnalyticsPage from "./pages/app/AnalyticsPage";
import CoachPage from "./pages/app/CoachPage";
import WeekPlanPage from "./pages/app/WeekPlanPage";
import NotificationsPage from "./pages/app/NotificationsPage";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Landing />} />
          <Route path="/auth" element={<AuthPage />} />
          <Route path="/app" element={<AppLayout />}>
            <Route index element={<Dashboard />} />
            <Route path="profile" element={<ProfilePage />} />
            <Route path="workouts" element={<WorkoutsPage />} />
            <Route path="nutrition" element={<NutritionPage />} />
            <Route path="diary" element={<DiaryPage />} />
            <Route path="progress" element={<ProgressPage />} />
            <Route path="analytics" element={<AnalyticsPage />} />
            <Route path="coach" element={<CoachPage />} />
            <Route path="week" element={<WeekPlanPage />} />
            <Route path="notifications" element={<NotificationsPage />} />
          </Route>
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
