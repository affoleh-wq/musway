import { useState, createContext, useContext, useEffect } from 'react';
import { NavLink as RouterNavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard, User, Dumbbell, Utensils, BookOpen, TrendingUp,
  BarChart3, MessageCircle, CalendarDays, Bell, Menu, X, Zap, Sun, Moon, LogOut
} from 'lucide-react';
import { useTheme } from '@/hooks/use-theme';
import { UserProfile, defaultProfile, FoodEntry } from '@/lib/mockData';
import { motion, AnimatePresence } from 'framer-motion';
import { api, clearToken, hasToken, BackendProfile } from '@/lib/api';
import { toast } from 'sonner';

const navItems = [
  { to: '/app', icon: LayoutDashboard, label: 'Дашборд', end: true },
  { to: '/app/profile', icon: User, label: 'Профиль' },
  { to: '/app/workouts', icon: Dumbbell, label: 'Тренировки' },
  { to: '/app/nutrition', icon: Utensils, label: 'Питание' },
  { to: '/app/diary', icon: BookOpen, label: 'Дневник' },
  { to: '/app/progress', icon: TrendingUp, label: 'Прогресс' },
  { to: '/app/analytics', icon: BarChart3, label: 'Аналитика' },
  { to: '/app/coach', icon: MessageCircle, label: 'Коуч' },
  { to: '/app/week', icon: CalendarDays, label: 'План недели' },
  { to: '/app/notifications', icon: Bell, label: 'Уведомления' },
];

const bottomNavItems = navItems.slice(0, 5);

interface AppContextType {
  profile: UserProfile;
  setProfile: (p: UserProfile) => void;
  diary: FoodEntry[];
  setDiary: (d: FoodEntry[]) => void;
  reloadProfile: () => Promise<void>;
  reloadDiary: () => Promise<void>;
}

const AppContext = createContext<AppContextType | null>(null);
export const useAppContext = () => useContext(AppContext)!;

function mapGoal(goal?: string | null): 'lose' | 'gain' | 'maintain' {
  const g = (goal || '').toLowerCase();
  if (g.includes('похуд') || g.includes('lose')) return 'lose';
  if (g.includes('набор') || g.includes('мас') || g.includes('gain')) return 'gain';
  return 'maintain';
}

function backendToProfile(data: BackendProfile): UserProfile {
  return {
    name: data.name || defaultProfile.name,
    goal: mapGoal(data.goal),
    weight: Number(data.weight || defaultProfile.weight),
    targetWeight: Number(data.weight_goal || defaultProfile.targetWeight),
    height: Number(data.height || defaultProfile.height),
    age: Number(data.age || defaultProfile.age),
    gender: data.gender === 'female' ? 'female' : 'male',
    activity: data.activity_level === 'high' ? 'high' : data.activity_level === 'low' ? 'low' : 'medium',
    allergies: data.allergies || '',
    excludeProducts: data.excluded_foods || '',
    mealsPerDay: Number(data.meals_per_day || defaultProfile.mealsPerDay),
  };
}

function foodEntryFromBackend(entry: any): FoodEntry {
  const date = entry.created_at ? new Date(entry.created_at) : new Date();
  return {
    id: String(entry.id),
    name: entry.text,
    calories: entry.calories,
    protein: entry.protein,
    fat: entry.fat,
    carbs: entry.carbs,
    time: date.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' }),
  };
}

export default function AppLayout() {
  const [profile, setProfile] = useState<UserProfile>(defaultProfile);
  const [diary, setDiary] = useState<FoodEntry[]>([]);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const { theme, toggleTheme } = useTheme();
  const location = useLocation();
  const navigate = useNavigate();

  const reloadProfile = async () => {
    const data = await api.getProfile();
    setProfile(backendToProfile(data));
  };

  const reloadDiary = async () => {
    const data = await api.getTodayFood();
    setDiary((data.entries || []).map(foodEntryFromBackend));
  };

  useEffect(() => {
    const run = async () => {
      if (!hasToken()) {
        navigate('/auth');
        return;
      }
      try {
        await Promise.all([reloadProfile(), reloadDiary()]);
      } catch (error) {
        clearToken();
        toast.error('Сессия истекла. Войди снова.');
        navigate('/auth');
      } finally {
        setLoading(false);
      }
    };
    void run();
  }, []);

  const logout = () => {
    clearToken();
    navigate('/auth');
  };

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center text-muted-foreground">Загрузка...</div>;
  }

  return (
    <AppContext.Provider value={{ profile, setProfile, diary, setDiary, reloadProfile, reloadDiary }}>
      <div className="min-h-screen flex bg-background">
        <aside className="hidden lg:flex flex-col w-60 border-r bg-card shrink-0 sticky top-0 h-screen">
          <div className="flex items-center gap-2 px-5 h-16 border-b font-bold">
            <div className="h-7 w-7 rounded-lg gradient-primary flex items-center justify-center">
              <Zap className="h-3.5 w-3.5 text-primary-foreground" />
            </div>
            FitCoach AI
          </div>
          <nav className="flex-1 py-3 px-3 space-y-0.5 overflow-y-auto">
            {navItems.map(item => (
              <RouterNavLink
                key={item.to}
                to={item.to}
                end={item.end}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition-colors ${
                    isActive ? 'bg-accent text-accent-foreground font-medium' : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                  }`
                }
              >
                <item.icon className="h-4 w-4" />
                {item.label}
              </RouterNavLink>
            ))}
          </nav>
          <div className="p-3 border-t space-y-1">
            <button
              onClick={toggleTheme}
              className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm w-full text-muted-foreground hover:bg-muted hover:text-foreground transition-colors"
            >
              {theme === 'light' ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
              {theme === 'light' ? 'Тёмная тема' : 'Светлая тема'}
            </button>
            <button
              onClick={logout}
              className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm w-full text-muted-foreground hover:bg-muted hover:text-foreground transition-colors"
            >
              <LogOut className="h-4 w-4" />
              Выйти
            </button>
          </div>
        </aside>

        <AnimatePresence>
          {sidebarOpen && (
            <>
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 bg-foreground/20 z-40 lg:hidden" onClick={() => setSidebarOpen(false)} />
              <motion.aside initial={{ x: -280 }} animate={{ x: 0 }} exit={{ x: -280 }} transition={{ type: 'spring', damping: 24, stiffness: 240 }} className="fixed left-0 top-0 bottom-0 w-72 bg-card border-r z-50 lg:hidden flex flex-col">
                <div className="h-14 border-b flex items-center justify-between px-4">
                  <div className="flex items-center gap-2 font-bold">
                    <div className="h-7 w-7 rounded-lg gradient-primary flex items-center justify-center">
                      <Zap className="h-3.5 w-3.5 text-primary-foreground" />
                    </div>
                    FitCoach AI
                  </div>
                  <button onClick={() => setSidebarOpen(false)}><X className="h-5 w-5" /></button>
                </div>
                <nav className="flex-1 py-3 px-3 space-y-0.5 overflow-y-auto">
                  {navItems.map(item => (
                    <RouterNavLink key={item.to} to={item.to} end={item.end} onClick={() => setSidebarOpen(false)} className={({ isActive }) => `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition-colors ${isActive ? 'bg-accent text-accent-foreground font-medium' : 'text-muted-foreground hover:bg-muted hover:text-foreground'}`}>
                      <item.icon className="h-4 w-4" />
                      {item.label}
                    </RouterNavLink>
                  ))}
                </nav>
              </motion.aside>
            </>
          )}
        </AnimatePresence>

        <div className="flex-1 flex flex-col min-w-0">
          <header className="lg:hidden sticky top-0 z-30 glass h-14 flex items-center px-4 gap-3">
            <button onClick={() => setSidebarOpen(true)}>
              <Menu className="h-5 w-5" />
            </button>
            <span className="font-semibold text-sm">
              {navItems.find(n => {
                if (n.end) return location.pathname === n.to;
                return location.pathname.startsWith(n.to);
              })?.label || 'FitCoach AI'}
            </span>
          </header>

          <main className="flex-1 pb-20 lg:pb-0">
            <Outlet />
          </main>

          <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-30 glass border-t">
            <div className="flex justify-around items-center h-16">
              {bottomNavItems.map(item => (
                <RouterNavLink key={item.to} to={item.to} end={item.end} className={({ isActive }) => `flex flex-col items-center gap-0.5 text-[10px] transition-colors ${isActive ? 'text-primary' : 'text-muted-foreground'}`}>
                  <item.icon className="h-5 w-5" />
                  {item.label}
                </RouterNavLink>
              ))}
            </div>
          </nav>
        </div>
      </div>
    </AppContext.Provider>
  );
}
