export interface UserProfile {
  name: string;
  goal: 'lose' | 'gain' | 'maintain';
  weight: number;
  targetWeight: number;
  height: number;
  age: number;
  gender: 'male' | 'female';
  activity: 'low' | 'medium' | 'high';
  allergies: string;
  excludeProducts: string;
  mealsPerDay: number;
}

export interface FoodEntry {
  id: string;
  name: string;
  calories: number;
  protein: number;
  fat: number;
  carbs: number;
  time: string;
}

export interface WorkoutExercise {
  name: string;
  sets: number;
  reps: string;
  rest: string;
}

export const defaultProfile: UserProfile = {
  name: 'Алексей',
  goal: 'lose',
  weight: 85,
  targetWeight: 75,
  height: 180,
  age: 28,
  gender: 'male',
  activity: 'medium',
  allergies: '',
  excludeProducts: '',
  mealsPerDay: 5,
};

export const calculateCalories = (p: UserProfile): number => {
  const bmr = p.gender === 'male'
    ? 10 * p.weight + 6.25 * p.height - 5 * p.age + 5
    : 10 * p.weight + 6.25 * p.height - 5 * p.age - 161;
  const multiplier = p.activity === 'low' ? 1.2 : p.activity === 'medium' ? 1.55 : 1.725;
  const tdee = bmr * multiplier;
  if (p.goal === 'lose') return Math.round(tdee - 500);
  if (p.goal === 'gain') return Math.round(tdee + 300);
  return Math.round(tdee);
};

export const mockFoodDiary: FoodEntry[] = [
  { id: '1', name: 'Овсянка с бананом', calories: 350, protein: 12, fat: 8, carbs: 55, time: '08:00' },
  { id: '2', name: 'Куриная грудка с рисом', calories: 450, protein: 40, fat: 10, carbs: 50, time: '13:00' },
  { id: '3', name: 'Греческий йогурт', calories: 150, protein: 15, fat: 5, carbs: 10, time: '16:00' },
];

export const mockWorkout: WorkoutExercise[] = [
  { name: 'Приседания', sets: 4, reps: '12', rest: '90 сек' },
  { name: 'Жим лёжа', sets: 4, reps: '10', rest: '90 сек' },
  { name: 'Тяга штанги в наклоне', sets: 3, reps: '12', rest: '60 сек' },
  { name: 'Выпады', sets: 3, reps: '10 на ногу', rest: '60 сек' },
  { name: 'Планка', sets: 3, reps: '45 сек', rest: '30 сек' },
];

export const mockMealPlan = [
  { meal: 'Завтрак', items: 'Овсянка с ягодами и орехами', calories: 380, protein: 14, fat: 12, carbs: 52 },
  { meal: 'Перекус', items: 'Яблоко + миндаль', calories: 200, protein: 5, fat: 12, carbs: 22 },
  { meal: 'Обед', items: 'Куриная грудка с гречкой и овощами', calories: 520, protein: 42, fat: 12, carbs: 58 },
  { meal: 'Перекус', items: 'Творог с бананом', calories: 250, protein: 20, fat: 5, carbs: 30 },
  { meal: 'Ужин', items: 'Рыба на пару с салатом', calories: 380, protein: 35, fat: 15, carbs: 18 },
  { meal: 'Вода', items: '8 стаканов (2 литра)', calories: 0, protein: 0, fat: 0, carbs: 0 },
];

export const weeklyWeightData = [
  { day: 'Пн', weight: 85.2 },
  { day: 'Вт', weight: 84.8 },
  { day: 'Ср', weight: 85.0 },
  { day: 'Чт', weight: 84.5 },
  { day: 'Пт', weight: 84.3 },
  { day: 'Сб', weight: 84.6 },
  { day: 'Вс', weight: 84.1 },
];

export const weeklyCaloriesData = [
  { day: 'Пн', calories: 2100, goal: 2200 },
  { day: 'Вт', calories: 2350, goal: 2200 },
  { day: 'Ср', calories: 2050, goal: 2200 },
  { day: 'Чт', calories: 2200, goal: 2200 },
  { day: 'Пт', calories: 1900, goal: 2200 },
  { day: 'Сб', calories: 2500, goal: 2200 },
  { day: 'Вс', calories: 2150, goal: 2200 },
];

export const weekPlan = [
  { day: 'Понедельник', activity: 'Силовая: верх тела', food: 'Высокобелковый день' },
  { day: 'Вторник', activity: 'Кардио 30 мин', food: 'Умеренные углеводы' },
  { day: 'Среда', activity: 'Силовая: ноги', food: 'Высокоуглеводный день' },
  { day: 'Четверг', activity: 'Отдых / растяжка', food: 'Лёгкий день' },
  { day: 'Пятница', activity: 'Силовая: всё тело', food: 'Высокобелковый день' },
  { day: 'Суббота', activity: 'Активный отдых', food: 'Свободный приём пищи' },
  { day: 'Воскресенье', activity: 'Отдых', food: 'Подготовка к неделе' },
];

export const coachResponses: Record<string, string> = {
  'Что съесть вечером?': 'Вечером лучше выбрать лёгкий белок с овощами — например, рыбу на пару с салатом или омлет с зеленью. Избегай тяжёлых углеводов за 3 часа до сна.',
  'Я переел': 'Не переживай, один день не разрушит прогресс! 💪 Завтра вернись к обычному режиму. Сегодня можно прогуляться 20-30 минут, чтобы помочь пищеварению.',
  'Нет мотивации': 'Мотивация приходит и уходит — это нормально. Попробуй поставить маленькую цель на сегодня: хотя бы 10 минут активности. Маленькие шаги ведут к большим результатам! 🎯',
};
