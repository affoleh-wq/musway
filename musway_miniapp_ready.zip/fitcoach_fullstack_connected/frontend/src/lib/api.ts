const API_BASE_URL = import.meta.env.VITE_API_URL || "http://127.0.0.1:8000";

export interface BackendProfile {
  id: number;
  email?: string | null;
  telegram_connected: boolean;
  name?: string | null;
  goal?: string | null;
  weight?: number | null;
  height?: number | null;
  age?: number | null;
  gender?: string | null;
  activity_level?: string | null;
  allergies?: string | null;
  excluded_foods?: string | null;
  meals_per_day?: number | null;
  daily_calorie_goal?: number | null;
  weight_goal?: number | null;
}

export function getToken() {
  return localStorage.getItem("fitcoach_token");
}

export function setToken(token: string) {
  localStorage.setItem("fitcoach_token", token);
}

export function clearToken() {
  localStorage.removeItem("fitcoach_token");
}

export function hasToken() {
  return !!getToken();
}

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const token = getToken();
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    ...(options.headers as Record<string, string>),
  };

  if (token) {
    headers["Authorization"] = `Bearer ${token}`;
  }

  const response = await fetch(`${API_BASE_URL}${path}`, { ...options, headers });
  if (!response.ok) {
    const text = await response.text();
    throw new Error(text || `HTTP ${response.status}`);
  }
  return response.json();
}

export const api = {
  start: () =>
    request<{ access_token: string; token_type: string }>("/api/auth/start", {
      method: "POST",
      body: JSON.stringify({}),
    }),

  register: (payload: { email: string; password: string; name: string }) =>
    request<{ access_token: string; token_type: string }>("/api/auth/register", {
      method: "POST",
      body: JSON.stringify(payload),
    }),

  login: (payload: { email: string; password: string }) =>
    request<{ access_token: string; token_type: string }>("/api/auth/login", {
      method: "POST",
      body: JSON.stringify(payload),
    }),

  me: () => request<BackendProfile>("/api/auth/me"),
  getProfile: () => request<BackendProfile>("/api/profile"),

  updateProfile: (payload: Record<string, unknown>) =>
    request<BackendProfile>("/api/profile", {
      method: "PUT",
      body: JSON.stringify(payload),
    }),

  addWeight: (payload: { weight: number }) =>
    request<{ ok: boolean; weight: number; daily_calorie_goal?: number }>("/api/weight", {
      method: "POST",
      body: JSON.stringify(payload),
    }),

  getWeightHistory: () =>
    request<Array<{ weight: number; created_at: string }>>("/api/weight/history"),

  getWeightProgress: () =>
    request<{
      start_weight: number | null;
      current_weight: number | null;
      difference: number | null;
      progress_percent: number | null;
      ai_summary: string;
      weight_logs: Array<{ weight: number; created_at: string }>;
    }>("/api/weight/progress"),

  generateWorkout: () =>
    request<{ text: string }>("/api/workout/generate", {
      method: "POST",
      body: JSON.stringify({}),
    }),

  getLatestWorkout: () => request<{ text: string }>("/api/workout/latest"),

  generateNutrition: () =>
    request<{ text: string }>("/api/nutrition/generate", {
      method: "POST",
      body: JSON.stringify({}),
    }),

  getLatestNutrition: () => request<{ text: string }>("/api/nutrition/latest"),
  getWeekPlan: () => request<{ text: string }>("/api/nutrition/week-plan"),

  addFood: (payload: { text: string }) =>
    request("/api/food/add", {
      method: "POST",
      body: JSON.stringify(payload),
    }),

  quickAddFood: (payload: { key: string }) =>
    request("/api/food/quick-add", {
      method: "POST",
      body: JSON.stringify(payload),
    }),

  getTodayFood: () =>
    request<{
      entries: Array<{
        id: number;
        text: string;
        calories: number;
        protein: number;
        fat: number;
        carbs: number;
        created_at: string;
      }>;
      total_calories: number;
      total_protein: number;
      total_fat: number;
      total_carbs: number;
      remaining_calories: number | null;
    }>("/api/food/today"),

  deleteLastFood: () =>
    request<{ ok: boolean; deleted: string }>("/api/food/last", { method: "DELETE" }),

  weeklyAnalytics: () =>
    request<{
      days: number;
      avg_calories: number;
      avg_protein: number;
      avg_fat: number;
      avg_carbs: number;
      message: string;
    }>("/api/analytics/weekly"),

  askCoach: (payload: { message: string }) =>
    request<{ answer: string }>("/api/coach/message", {
      method: "POST",
      body: JSON.stringify(payload),
    }),

  getNotifications: () => request<any>("/api/notifications"),
  updateNotifications: (payload: Record<string, unknown>) =>
    request("/api/notifications", {
      method: "PUT",
      body: JSON.stringify(payload),
    }),
};
