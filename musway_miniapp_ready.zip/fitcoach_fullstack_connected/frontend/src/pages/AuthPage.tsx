import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { api, hasToken, setToken } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "sonner";
import { ArrowRight, CheckCircle2, Sparkles, Target, Zap } from "lucide-react";
import { UserProfile, calculateCalories, defaultProfile } from "@/lib/mockData";
import { getTelegramUser, isTelegramMiniApp } from "@/lib/telegram";

const goals = [
  { value: "lose" as const, label: "Похудение" },
  { value: "gain" as const, label: "Набор массы" },
  { value: "maintain" as const, label: "Поддержание" },
];

const activities = [
  { value: "low" as const, label: "Низкая" },
  { value: "medium" as const, label: "Средняя" },
  { value: "high" as const, label: "Высокая" },
];

function goalToBackend(goal: UserProfile["goal"]) {
  if (goal === "lose") return "похудение";
  if (goal === "gain") return "набор массы";
  return "поддержание";
}

export default function AuthPage() {
  const navigate = useNavigate();
  const telegramUser = getTelegramUser();
  const openedInTelegram = isTelegramMiniApp();
  const autoStartDone = useRef(false);

  const [started, setStarted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState<UserProfile>({
    ...defaultProfile,
    name: telegramUser?.first_name || defaultProfile.name,
  });

  useEffect(() => {
    if (hasToken()) {
      navigate("/app");
    }
  }, [navigate]);

  useEffect(() => {
    if (!openedInTelegram || autoStartDone.current || hasToken()) return;

    autoStartDone.current = true;
    void (async () => {
      setLoading(true);
      try {
        const result = await api.start();
        setToken(result.access_token);
        setStarted(true);
        toast.success("Mini App открыт. Давай заполним профиль");
      } catch (error) {
        toast.error(error instanceof Error ? error.message : "Не удалось начать");
      } finally {
        setLoading(false);
      }
    })();
  }, [openedInTelegram]);

  const calories = useMemo(() => calculateCalories(form), [form]);

  const update = (key: keyof UserProfile, value: string | number) => {
    setForm((prev) => ({ ...prev, [key]: value }));
  };

  const start = async () => {
    setLoading(true);
    try {
      const result = await api.start();
      setToken(result.access_token);
      setStarted(true);
      toast.success("Отлично, давай познакомимся");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Не удалось начать");
    } finally {
      setLoading(false);
    }
  };

  const submitOnboarding = async () => {
    setLoading(true);
    try {
      await api.updateProfile({
        name: form.name,
        goal: goalToBackend(form.goal),
        weight: Number(form.weight),
        height: Number(form.height),
        age: Number(form.age),
        gender: form.gender,
        activity_level: form.activity,
        allergies: form.allergies,
        excluded_foods: form.excludeProducts,
        meals_per_day: Number(form.mealsPerDay),
        weight_goal: Number(form.targetWeight),
        daily_calorie_goal: calories,
      });
      toast.success("Профиль готов");
      navigate("/app");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Не удалось сохранить анкету");
    } finally {
      setLoading(false);
    }
  };

  if (!started) {
    return (
      <div className="min-h-screen gradient-hero flex items-center justify-center p-4">
        <Card className="w-full max-w-lg rounded-3xl shadow-card border">
          <CardHeader className="space-y-4 text-center">
            <div className="mx-auto h-14 w-14 rounded-2xl gradient-primary flex items-center justify-center">
              <Zap className="h-6 w-6 text-primary-foreground" />
            </div>
            <CardTitle className="text-3xl">MUSWAY</CardTitle>
            <CardDescription className="text-base">
              {openedInTelegram
                ? "Ты открыл mini app внутри Telegram. Нажми кнопку ниже, чтобы создать профиль и перейти к онбордингу."
                : "Нажми «Начать», а затем заполни короткий онбординг. После этого приложение подготовит персональный профиль."}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {telegramUser && (
              <div className="rounded-2xl border bg-accent/40 p-4 text-sm">
                Открыто из Telegram{telegramUser.first_name ? ` как ${telegramUser.first_name}` : ""}
                {telegramUser.username ? ` (@${telegramUser.username})` : ""}
              </div>
            )}

            <div className="grid gap-3 text-sm">
              <div className="rounded-2xl border bg-accent/40 p-4 flex gap-3 items-start">
                <Sparkles className="h-5 w-5 mt-0.5 text-primary" />
                <div>
                  <p className="font-medium">Быстрый старт</p>
                  <p className="text-muted-foreground">Без email и пароля — пользователь сразу попадает в анкету.</p>
                </div>
              </div>
              <div className="rounded-2xl border bg-accent/40 p-4 flex gap-3 items-start">
                <Target className="h-5 w-5 mt-0.5 text-primary" />
                <div>
                  <p className="font-medium">Персональный план</p>
                  <p className="text-muted-foreground">Укажи цель, параметры и активность, чтобы получить релевантные рекомендации.</p>
                </div>
              </div>
            </div>
            <Button onClick={start} disabled={loading} className="w-full gradient-primary text-primary-foreground rounded-xl h-12 text-base">
              {loading ? "Загрузка..." : openedInTelegram ? "Открыть онбординг" : "Начать"}
              {!loading && <ArrowRight className="ml-2 h-4 w-4" />}
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen gradient-hero py-8 px-4">
      <div className="max-w-3xl mx-auto space-y-4">
        <div className="text-center text-white/90">
          <p className="text-sm uppercase tracking-[0.2em] mb-2">Онбординг</p>
          <h1 className="text-3xl md:text-4xl font-bold text-white">Давай настроим твой профиль</h1>
          <p className="mt-2 text-white/70">Это займёт меньше минуты, зато дальше рекомендации будут гораздо точнее.</p>
        </div>

        <Card className="rounded-3xl shadow-card border">
          <CardContent className="p-6 md:p-8 space-y-6">
            {telegramUser && (
              <div className="rounded-2xl border bg-accent/40 p-4 text-sm">
                Telegram mini app активен. Имя подставлено автоматически, если оно было доступно.
              </div>
            )}

            <div>
              <Label>Как тебя зовут</Label>
              <Input value={form.name} onChange={(e) => update("name", e.target.value)} className="mt-1.5 rounded-xl" />
            </div>

            <div>
              <Label>Твоя цель</Label>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-2 mt-1.5">
                {goals.map((goal) => (
                  <button
                    key={goal.value}
                    onClick={() => update("goal", goal.value)}
                    className={`rounded-xl py-3 text-sm font-medium border transition-colors ${
                      form.goal === goal.value ? "bg-primary text-primary-foreground border-primary" : "bg-muted border-border"
                    }`}
                  >
                    {goal.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div>
                <Label>Вес, кг</Label>
                <Input type="number" value={form.weight} onChange={(e) => update("weight", Number(e.target.value))} className="mt-1.5 rounded-xl" />
              </div>
              <div>
                <Label>Цель веса, кг</Label>
                <Input type="number" value={form.targetWeight} onChange={(e) => update("targetWeight", Number(e.target.value))} className="mt-1.5 rounded-xl" />
              </div>
              <div>
                <Label>Рост, см</Label>
                <Input type="number" value={form.height} onChange={(e) => update("height", Number(e.target.value))} className="mt-1.5 rounded-xl" />
              </div>
              <div>
                <Label>Возраст</Label>
                <Input type="number" value={form.age} onChange={(e) => update("age", Number(e.target.value))} className="mt-1.5 rounded-xl" />
              </div>
            </div>

            <div>
              <Label>Пол</Label>
              <div className="grid grid-cols-2 gap-2 mt-1.5">
                {[
                  { value: "male", label: "Мужчина" },
                  { value: "female", label: "Женщина" },
                ].map((gender) => (
                  <button
                    key={gender.value}
                    onClick={() => update("gender", gender.value)}
                    className={`rounded-xl py-3 text-sm font-medium border transition-colors ${
                      form.gender === gender.value ? "bg-primary text-primary-foreground border-primary" : "bg-muted border-border"
                    }`}
                  >
                    {gender.label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <Label>Уровень активности</Label>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-2 mt-1.5">
                {activities.map((activity) => (
                  <button
                    key={activity.value}
                    onClick={() => update("activity", activity.value)}
                    className={`rounded-xl py-3 text-sm font-medium border transition-colors ${
                      form.activity === activity.value ? "bg-primary text-primary-foreground border-primary" : "bg-muted border-border"
                    }`}
                  >
                    {activity.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <Label>Аллергии</Label>
                <Input value={form.allergies} onChange={(e) => update("allergies", e.target.value)} className="mt-1.5 rounded-xl" placeholder="Например: орехи, лактоза" />
              </div>
              <div>
                <Label>Исключить продукты</Label>
                <Input value={form.excludeProducts} onChange={(e) => update("excludeProducts", e.target.value)} className="mt-1.5 rounded-xl" placeholder="Например: сахар, свинина" />
              </div>
            </div>

            <div>
              <Label>Сколько приёмов пищи в день удобно</Label>
              <Input type="number" value={form.mealsPerDay} onChange={(e) => update("mealsPerDay", Number(e.target.value))} className="mt-1.5 rounded-xl max-w-xs" />
            </div>

            <div className="rounded-2xl bg-accent p-4 flex items-center justify-between gap-4">
              <div>
                <p className="text-sm text-muted-foreground">Рекомендованная дневная норма</p>
                <p className="text-2xl font-bold">{calories} ккал</p>
              </div>
              <CheckCircle2 className="h-8 w-8 text-primary shrink-0" />
            </div>

            <Button onClick={submitOnboarding} disabled={loading} className="w-full gradient-primary text-primary-foreground rounded-xl h-12 text-base">
              {loading ? "Сохраняю..." : "Завершить и открыть приложение"}
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
