import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import {
  User, Utensils, Dumbbell, BookOpen, TrendingUp, BarChart3,
  MessageCircle, CalendarDays, ArrowRight, Star, Zap, Target, CheckCircle2
} from 'lucide-react';
import { Button } from '@/components/ui/button';

const features = [
  { icon: User, title: 'Профиль', desc: 'Настрой цели и параметры' },
  { icon: Utensils, title: 'Питание', desc: 'Персональный план питания' },
  { icon: Dumbbell, title: 'Тренировки', desc: 'AI-генерация программ' },
  { icon: BookOpen, title: 'Дневник питания', desc: 'Трекинг калорий и БЖУ' },
  { icon: TrendingUp, title: 'Прогресс', desc: 'Отслеживание результатов' },
  { icon: BarChart3, title: 'Аналитика', desc: 'Графики и инсайты' },
  { icon: MessageCircle, title: 'AI-коуч', desc: 'Персональные советы 24/7' },
  { icon: CalendarDays, title: 'План недели', desc: 'Готовая программа на 7 дней' },
];

const steps = [
  { num: '01', title: 'Заполни профиль', desc: 'Укажи свои параметры и цели' },
  { num: '02', title: 'Получи план', desc: 'AI создаст питание и тренировки' },
  { num: '03', title: 'Следуй и расти', desc: 'Отслеживай прогресс каждый день' },
];

const testimonials = [
  { name: 'Мария К.', text: 'Сбросила 8 кг за 2 месяца! Питание подобрано идеально.', stars: 5 },
  { name: 'Дмитрий В.', text: 'AI-коуч реально мотивирует. Как персональный тренер в кармане.', stars: 5 },
  { name: 'Анна С.', text: 'Наконец-то удобный трекер еды. Простой и понятный.', stars: 5 },
];

const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: (i: number) => ({
    opacity: 1, y: 0,
    transition: { delay: i * 0.1, duration: 0.5, ease: 'easeOut' }
  }),
};

export default function Landing() {
  return (
    <div className="min-h-screen bg-background">
      {/* Nav */}
      <nav className="sticky top-0 z-50 glass">
        <div className="container mx-auto flex items-center justify-between h-16 px-4">
          <Link to="/" className="flex items-center gap-2 font-bold text-lg">
            <div className="h-8 w-8 rounded-lg gradient-primary flex items-center justify-center">
              <Zap className="h-4 w-4 text-primary-foreground" />
            </div>
            FitCoach AI
          </Link>
          <Link to="/auth">
            <Button size="sm" className="gradient-primary text-primary-foreground shadow-primary hover:opacity-90 transition-opacity">
              Войти
            </Button>
          </Link>
        </div>
      </nav>

      {/* Hero */}
      <section className="gradient-hero">
        <div className="container mx-auto px-4 py-24 md:py-32 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="inline-flex items-center gap-2 rounded-full bg-accent px-4 py-1.5 text-sm text-accent-foreground mb-6">
              <Zap className="h-3.5 w-3.5" />
              Бесплатный AI фитнес-ассистент
            </div>
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold tracking-tight mb-6">
              Твой AI{' '}
              <span className="text-primary">фитнес-коуч</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-10">
              Питание, тренировки и прогресс — всё в одном месте. Персональный подход на основе искусственного интеллекта.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/auth">
                <Button size="lg" className="gradient-primary text-primary-foreground shadow-primary hover:opacity-90 transition-opacity text-base px-8 h-12">
                  Начать бесплатно
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
              <Button size="lg" variant="outline" className="text-base px-8 h-12">
                Смотреть демо
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 md:py-28">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Всё для твоей формы</h2>
            <p className="text-muted-foreground text-lg max-w-xl mx-auto">
              Комплексный подход к фитнесу с AI
            </p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
            {features.map((f, i) => (
              <motion.div
                key={f.title}
                custom={i}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true }}
                variants={fadeUp}
                className="group bg-card rounded-2xl p-6 shadow-card border hover:shadow-elevated transition-shadow duration-300"
              >
                <div className="h-10 w-10 rounded-xl bg-accent flex items-center justify-center mb-4 group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                  <f.icon className="h-5 w-5" />
                </div>
                <h3 className="font-semibold mb-1">{f.title}</h3>
                <p className="text-sm text-muted-foreground">{f.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="py-20 bg-muted/50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-16">Как это работает</h2>
          <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            {steps.map((s, i) => (
              <motion.div
                key={s.num}
                custom={i}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true }}
                variants={fadeUp}
                className="text-center"
              >
                <div className="text-5xl font-bold text-primary/20 mb-4">{s.num}</div>
                <h3 className="text-xl font-semibold mb-2">{s.title}</h3>
                <p className="text-muted-foreground">{s.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Dashboard Preview */}
      <section className="py-20 md:py-28">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Интуитивный интерфейс</h2>
            <p className="text-muted-foreground text-lg">Всё под контролем на одном экране</p>
          </div>
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="max-w-4xl mx-auto bg-card rounded-3xl shadow-elevated border p-6 md:p-8"
          >
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              {[
                { label: 'Вес', value: '84.1 кг', sub: '↓ 0.9 кг' },
                { label: 'Цель', value: '75 кг', sub: 'осталось 9.1 кг' },
                { label: 'Калории', value: '1 730', sub: 'из 2 200' },
                { label: 'Активность', value: '65%', sub: 'сегодня' },
              ].map(c => (
                <div key={c.label} className="bg-muted/50 rounded-2xl p-4">
                  <p className="text-xs text-muted-foreground mb-1">{c.label}</p>
                  <p className="text-xl font-bold">{c.value}</p>
                  <p className="text-xs text-primary">{c.sub}</p>
                </div>
              ))}
            </div>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="bg-accent/50 rounded-2xl p-5">
                <p className="font-semibold mb-3">🍽 Сегодняшний рацион</p>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between"><span>Овсянка с бананом</span><span className="text-muted-foreground">350 ккал</span></div>
                  <div className="flex justify-between"><span>Курица с рисом</span><span className="text-muted-foreground">450 ккал</span></div>
                  <div className="flex justify-between"><span>Йогурт</span><span className="text-muted-foreground">150 ккал</span></div>
                </div>
              </div>
              <div className="bg-accent/50 rounded-2xl p-5">
                <p className="font-semibold mb-3">💡 AI совет дня</p>
                <p className="text-sm text-muted-foreground">Сегодня отличный день для кардио! Попробуй 20-минутную пробежку перед ужином — это ускорит метаболизм и улучшит сон.</p>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-muted/50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-16">Отзывы пользователей</h2>
          <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            {testimonials.map((t, i) => (
              <motion.div
                key={t.name}
                custom={i}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true }}
                variants={fadeUp}
                className="bg-card rounded-2xl p-6 shadow-card border"
              >
                <div className="flex gap-0.5 mb-4">
                  {Array.from({ length: t.stars }).map((_, j) => (
                    <Star key={j} className="h-4 w-4 fill-primary text-primary" />
                  ))}
                </div>
                <p className="text-sm mb-4">{t.text}</p>
                <p className="text-sm font-semibold">{t.name}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-24">
        <div className="container mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="max-w-2xl mx-auto gradient-primary rounded-3xl p-12 text-primary-foreground"
          >
            <Target className="h-10 w-10 mx-auto mb-4 opacity-80" />
            <h2 className="text-3xl font-bold mb-4">Готов начать?</h2>
            <p className="opacity-90 mb-8">Присоединяйся к тысячам людей, которые уже меняют свою жизнь</p>
            <Link to="/auth">
              <Button size="lg" className="bg-primary-foreground text-primary hover:bg-primary-foreground/90 text-base px-8 h-12">
                Начать бесплатно
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t py-8">
        <div className="container mx-auto px-4 flex items-center justify-between text-sm text-muted-foreground">
          <div className="flex items-center gap-2">
            <div className="h-6 w-6 rounded-md gradient-primary flex items-center justify-center">
              <Zap className="h-3 w-3 text-primary-foreground" />
            </div>
            FitCoach AI
          </div>
          <p>© 2026 Все права защищены</p>
        </div>
      </footer>
    </div>
  );
}
