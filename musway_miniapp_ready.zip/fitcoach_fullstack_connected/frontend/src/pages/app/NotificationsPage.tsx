import { useEffect, useState } from 'react';
import { Bell, Droplets, Utensils, Dumbbell } from 'lucide-react';
import { Switch } from '@/components/ui/switch';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';
import { api } from '@/lib/api';

export default function NotificationsPage() {
  const [all, setAll] = useState(true);
  const [water, setWater] = useState(true);
  const [food, setFood] = useState(true);
  const [workout, setWorkout] = useState(true);
  const [waterTime, setWaterTime] = useState('09:00');
  const [foodTime, setFoodTime] = useState('12:00');
  const [workoutTime, setWorkoutTime] = useState('18:00');

  useEffect(() => {
    api.getNotifications().then((data) => {
      setAll(!!data.notifications_enabled);
      setWater(!!data.water_notifications);
      setFood(!!data.meal_notifications);
      setWorkout(!!data.workout_notifications);
      setWaterTime(data.water_time || '09:00');
      setFoodTime(data.meal_time || '12:00');
      setWorkoutTime(data.workout_time || '18:00');
    }).catch(() => {});
  }, []);

  const save = async (patch: any) => {
    await api.updateNotifications(patch);
  };

  const toggleAll = async (v: boolean) => {
    setAll(v); setWater(v); setFood(v); setWorkout(v);
    await save({
      notifications_enabled: v,
      water_notifications: v,
      meal_notifications: v,
      workout_notifications: v,
    });
    toast.success(v ? 'Уведомления включены' : 'Уведомления выключены');
  };

  const rows = [
    { icon: Droplets, label: 'Напоминание о воде', active: water, setActive: setWater, time: waterTime, setTime: setWaterTime, key: 'water' },
    { icon: Utensils, label: 'Напоминание о еде', active: food, setActive: setFood, time: foodTime, setTime: setFoodTime, key: 'meal' },
    { icon: Dumbbell, label: 'Напоминание о тренировке', active: workout, setActive: setWorkout, time: workoutTime, setTime: setWorkoutTime, key: 'workout' },
  ] as const;

  return (
    <div className="p-4 md:p-8 max-w-2xl mx-auto space-y-6">
      <h1 className="text-2xl font-bold">Уведомления</h1>

      <div className="bg-card rounded-2xl p-5 shadow-card border space-y-5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-accent flex items-center justify-center">
              <Bell className="h-5 w-5 text-accent-foreground" />
            </div>
            <div>
              <p className="font-medium">Все уведомления</p>
              <p className="text-xs text-muted-foreground">Включить или выключить всё</p>
            </div>
          </div>
          <Switch checked={all} onCheckedChange={toggleAll} />
        </div>

        <div className="h-px bg-border" />

        {rows.map((row) => (
          <div key={row.label} className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <row.icon className="h-5 w-5 text-primary" />
                <p className="font-medium">{row.label}</p>
              </div>
              <Switch checked={row.active} onCheckedChange={async (v) => {
                row.setActive(v);
                await save({ [`${row.key}_notifications`]: v, notifications_enabled: true });
              }} />
            </div>
            <Input type="time" value={row.time} onChange={async (e) => {
              row.setTime(e.target.value);
              await save({ [`${row.key}_time`]: e.target.value, notifications_enabled: true });
            }} className="rounded-xl" />
          </div>
        ))}
      </div>
    </div>
  );
}
