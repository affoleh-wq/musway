import { useEffect, useState } from 'react';
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, Tooltip } from 'recharts';
import { TrendingDown, Target, Scale } from 'lucide-react';
import { motion } from 'framer-motion';
import { api } from '@/lib/api';

export default function ProgressPage() {
  const [data, setData] = useState<any>(null);

  useEffect(() => {
    api.getWeightProgress().then(setData).catch(() => setData(null));
  }, []);

  const chartData = (data?.weight_logs || []).map((x: any) => ({
    day: new Date(x.created_at).toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit' }),
    weight: x.weight,
  }));

  return (
    <div className="p-4 md:p-8 max-w-2xl mx-auto space-y-6">
      <h1 className="text-2xl font-bold">Прогресс</h1>

      <div className="grid grid-cols-3 gap-3">
        {[
          { icon: Scale, label: 'Старт', value: data?.start_weight ? `${data.start_weight} кг` : '—' },
          { icon: TrendingDown, label: 'Текущий', value: data?.current_weight ? `${data.current_weight} кг` : '—' },
          { icon: Target, label: 'Разница', value: data?.difference !== null && data?.difference !== undefined ? `${data.difference > 0 ? '+' : ''}${data.difference.toFixed(1)} кг` : '—' },
        ].map((c, i) => (
          <motion.div key={c.label} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.08 }} className="bg-card rounded-2xl p-4 shadow-card border text-center">
            <c.icon className="h-5 w-5 mx-auto mb-2 text-primary" />
            <p className="text-xs text-muted-foreground">{c.label}</p>
            <p className="text-lg font-bold">{c.value}</p>
          </motion.div>
        ))}
      </div>

      <div className="bg-card rounded-2xl p-5 shadow-card border">
        <div className="flex justify-between items-center mb-2">
          <span className="text-sm font-medium">Прогресс к цели</span>
          <span className="text-sm text-primary font-semibold">{data?.progress_percent ?? 0}%</span>
        </div>
        <div className="w-full h-3 bg-muted rounded-full overflow-hidden">
          <div className="h-full bg-primary rounded-full" style={{ width: `${data?.progress_percent ?? 0}%` }} />
        </div>
      </div>

      <div className="bg-card rounded-2xl p-5 shadow-card border">
        <h3 className="font-semibold mb-4">📈 История веса</h3>
        <div className="h-56">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData}>
              <XAxis dataKey="day" tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 12 }} axisLine={false} tickLine={false} domain={['dataMin - 1', 'dataMax + 1']} />
              <Tooltip />
              <Line type="monotone" dataKey="weight" stroke="hsl(142, 71%, 45%)" strokeWidth={3} dot />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="bg-card rounded-2xl p-5 shadow-card border">
        <h3 className="font-semibold mb-2">🤖 AI-анализ</h3>
        <p className="text-sm text-muted-foreground whitespace-pre-wrap">{data?.ai_summary || 'Пока мало данных для анализа.'}</p>
      </div>
    </div>
  );
}
