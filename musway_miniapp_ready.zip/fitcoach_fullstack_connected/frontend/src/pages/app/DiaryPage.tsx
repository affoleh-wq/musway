import { useState } from 'react';
import { useAppContext } from '@/components/AppLayout';
import { calculateCalories } from '@/lib/mockData';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Plus, Camera, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { motion } from 'framer-motion';
import { api } from '@/lib/api';

const quickFoods = [
  { key: 'Курица 200г', name: 'Курица' },
  { key: 'Рис 150г', name: 'Рис' },
  { key: 'Яблоко', name: 'Яблоко' },
  { key: '2 яйца', name: 'Яйца (2 шт)' },
  { key: 'Йогурт', name: 'Йогурт' },
  { key: 'Орехи 30г', name: 'Орехи' },
];

export default function DiaryPage() {
  const { profile, diary, reloadDiary } = useAppContext();
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const calorieGoal = calculateCalories(profile);

  const addCustom = async () => {
    if (!input.trim()) return;
    setLoading(true);
    try {
      await api.addFood({ text: input });
      setInput('');
      await reloadDiary();
      toast.success('Запись добавлена');
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Не удалось добавить еду');
    } finally {
      setLoading(false);
    }
  };

  const quickAdd = async (key: string) => {
    try {
      await api.quickAddFood({ key });
      await reloadDiary();
      toast.success('Быстрый продукт добавлен');
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Не удалось добавить продукт');
    }
  };

  const removeLast = async () => {
    try {
      await api.deleteLastFood();
      await reloadDiary();
      toast.success('Последняя запись удалена');
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Не удалось удалить запись');
    }
  };

  const totalCal = diary.reduce((s, e) => s + e.calories, 0);
  const remaining = calorieGoal - totalCal;

  return (
    <div className="p-4 md:p-8 max-w-2xl mx-auto space-y-6">
      <h1 className="text-2xl font-bold">Дневник питания</h1>

      <div className="flex gap-2">
        <Input value={input} onChange={e => setInput(e.target.value)} placeholder="Название продукта..." onKeyDown={e => e.key === 'Enter' && addCustom()} className="rounded-xl" />
        <Button onClick={addCustom} disabled={loading} className="gradient-primary text-primary-foreground rounded-xl px-4"><Plus className="h-4 w-4" /></Button>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
        {quickFoods.map(food => (
          <button key={food.key} onClick={() => quickAdd(food.key)} className="bg-card rounded-xl p-3 border text-sm font-medium hover:bg-accent transition-colors">
            {food.name}
          </button>
        ))}
      </div>

      <div className="flex justify-between gap-3">
        <div className="bg-card rounded-2xl border p-4 flex-1">
          <p className="text-xs text-muted-foreground">Съедено</p>
          <p className="text-2xl font-bold">{totalCal} ккал</p>
        </div>
        <div className="bg-card rounded-2xl border p-4 flex-1">
          <p className="text-xs text-muted-foreground">Осталось</p>
          <p className="text-2xl font-bold">{remaining} ккал</p>
        </div>
      </div>

      <div className="space-y-3">
        {diary.map((e, i) => (
          <motion.div key={e.id} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.03 }} className="bg-card rounded-2xl p-4 shadow-card border">
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="font-medium">{e.name}</p>
                <p className="text-xs text-muted-foreground mt-1">{e.time}</p>
              </div>
              <div className="text-right">
                <p className="font-bold">{e.calories} ккал</p>
                <p className="text-xs text-muted-foreground">Б {e.protein} • Ж {e.fat} • У {e.carbs}</p>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="flex gap-2">
        <Button variant="outline" className="flex-1 rounded-xl"><Camera className="mr-2 h-4 w-4" />Фото пока только в Telegram</Button>
        <Button variant="destructive" className="rounded-xl" onClick={removeLast}><Trash2 className="mr-2 h-4 w-4" />Удалить последнее</Button>
      </div>
    </div>
  );
}
