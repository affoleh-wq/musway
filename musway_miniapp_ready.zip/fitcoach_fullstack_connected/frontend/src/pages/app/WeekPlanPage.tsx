import { useEffect, useState } from 'react';
import { CalendarDays } from 'lucide-react';
import { motion } from 'framer-motion';
import { api } from '@/lib/api';

export default function WeekPlanPage() {
  const [text, setText] = useState('');

  useEffect(() => {
    api.getWeekPlan().then((data) => setText(data.text || '')).catch(() => {});
  }, []);

  return (
    <div className="p-4 md:p-8 max-w-2xl mx-auto space-y-6">
      <h1 className="text-2xl font-bold">План недели</h1>
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-card rounded-2xl p-5 shadow-card border">
        <div className="flex items-center gap-2 mb-3">
          <CalendarDays className="h-4 w-4 text-primary" />
          <h3 className="font-semibold">Сгенерированный план</h3>
        </div>
        <pre className="whitespace-pre-wrap text-sm leading-6">{text || 'План пока не загружен.'}</pre>
      </motion.div>
    </div>
  );
}
