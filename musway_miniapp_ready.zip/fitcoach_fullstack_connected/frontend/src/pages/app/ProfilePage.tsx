import { useEffect, useState } from 'react';
import { useAppContext } from '@/components/AppLayout';
import { calculateCalories, UserProfile } from '@/lib/mockData';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { CheckCircle2 } from 'lucide-react';
import { api } from '@/lib/api';

const goals = [
  { value: 'lose' as const, label: 'Похудение' },
  { value: 'gain' as const, label: 'Набор массы' },
  { value: 'maintain' as const, label: 'Поддержание' },
];

const activities = [
  { value: 'low' as const, label: 'Низкая' },
  { value: 'medium' as const, label: 'Средняя' },
  { value: 'high' as const, label: 'Высокая' },
];

function goalToBackend(goal: UserProfile['goal']) {
  if (goal === 'lose') return 'похудение';
  if (goal === 'gain') return 'набор массы';
  return 'поддержание';
}

export default function ProfilePage() {
  const { profile, setProfile, reloadProfile } = useAppContext();
  const [form, setForm] = useState<UserProfile>({ ...profile });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setForm({ ...profile });
  }, [profile]);

  const update = (key: keyof UserProfile, value: string | number) => {
    setForm(prev => ({ ...prev, [key]: value }));
  };

  const save = async () => {
    setSaving(true);
    try {
      await api.updateProfile({
        name: form.name,
        goal: goalToBackend(form.goal),
        weight: Number(form.weight),
        height: Number(form.height),
        age: Number(form.age),
        gender: form.gender,
        activity_level: form.activity,
        allergies: form.allergies,
        excluded_foods: form.excludeProducts,
        meals_per_day: Number(form.mealsPerDay),
        weight_goal: Number(form.targetWeight),
        daily_calorie_goal: calculateCalories(form),
      });
      await reloadProfile();
      setProfile(form);
      toast.success('Профиль сохранён!');
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Не удалось сохранить профиль');
    } finally {
      setSaving(false);
    }
  };

  const calories = calculateCalories(form);

  return (
    <div className="p-4 md:p-8 max-w-2xl mx-auto space-y-6">
      <h1 className="text-2xl font-bold">Профиль</h1>

      <div className="bg-card rounded-2xl p-6 shadow-card border space-y-5">
        <div>
          <Label>Имя</Label>
          <Input value={form.name} onChange={e => update('name', e.target.value)} className="mt-1.5 rounded-xl" />
        </div>

        <div>
          <Label>Цель</Label>
          <div className="grid grid-cols-3 gap-2 mt-1.5">
            {goals.map(g => (
              <button key={g.value} onClick={() => update('goal', g.value)} className={`rounded-xl py-2.5 text-sm font-medium border transition-colors ${form.goal === g.value ? 'bg-primary text-primary-foreground border-primary' : 'bg-muted border-border'}`}>
                {g.label}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div><Label>Вес</Label><Input type="number" value={form.weight} onChange={e => update('weight', Number(e.target.value))} className="mt-1.5 rounded-xl" /></div>
          <div><Label>Цель веса</Label><Input type="number" value={form.targetWeight} onChange={e => update('targetWeight', Number(e.target.value))} className="mt-1.5 rounded-xl" /></div>
          <div><Label>Рост</Label><Input type="number" value={form.height} onChange={e => update('height', Number(e.target.value))} className="mt-1.5 rounded-xl" /></div>
          <div><Label>Возраст</Label><Input type="number" value={form.age} onChange={e => update('age', Number(e.target.value))} className="mt-1.5 rounded-xl" /></div>
        </div>

        <div>
          <Label>Пол</Label>
          <div className="grid grid-cols-2 gap-2 mt-1.5">
            {['male', 'female'].map(g => (
              <button key={g} onClick={() => update('gender', g)} className={`rounded-xl py-2.5 text-sm font-medium border transition-colors ${form.gender === g ? 'bg-primary text-primary-foreground border-primary' : 'bg-muted border-border'}`}>
                {g === 'male' ? 'Мужчина' : 'Женщина'}
              </button>
            ))}
          </div>
        </div>

        <div>
          <Label>Активность</Label>
          <div className="grid grid-cols-3 gap-2 mt-1.5">
            {activities.map(a => (
              <button key={a.value} onClick={() => update('activity', a.value)} className={`rounded-xl py-2.5 text-sm font-medium border transition-colors ${form.activity === a.value ? 'bg-primary text-primary-foreground border-primary' : 'bg-muted border-border'}`}>
                {a.label}
              </button>
            ))}
          </div>
        </div>

        <div><Label>Аллергии</Label><Input value={form.allergies} onChange={e => update('allergies', e.target.value)} className="mt-1.5 rounded-xl" /></div>
        <div><Label>Исключить продукты</Label><Input value={form.excludeProducts} onChange={e => update('excludeProducts', e.target.value)} className="mt-1.5 rounded-xl" /></div>
        <div><Label>Приёмов пищи</Label><Input type="number" value={form.mealsPerDay} onChange={e => update('mealsPerDay', Number(e.target.value))} className="mt-1.5 rounded-xl" /></div>

        <div className="rounded-2xl bg-accent p-4 flex items-center justify-between">
          <div>
            <p className="text-sm text-muted-foreground">Рекомендованная цель калорий</p>
            <p className="text-2xl font-bold">{calories} ккал</p>
          </div>
          <CheckCircle2 className="h-8 w-8 text-primary" />
        </div>

        <Button onClick={save} disabled={saving} className="w-full gradient-primary text-primary-foreground rounded-xl h-12">
          {saving ? 'Сохраняю...' : 'Сохранить профиль'}
        </Button>
      </div>
    </div>
  );
}
