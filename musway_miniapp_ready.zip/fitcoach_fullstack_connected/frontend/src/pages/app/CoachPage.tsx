import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Send, MessageCircle, Bot, User } from 'lucide-react';
import { motion } from 'framer-motion';
import { api } from '@/lib/api';

interface Message {
  id: string;
  role: 'user' | 'coach';
  text: string;
}

const quickBtns = ['Что съесть вечером?', 'Я переел, что делать?', 'Нет мотивации'];

export default function CoachPage() {
  const [messages, setMessages] = useState<Message[]>([
    { id: '0', role: 'coach', text: 'Привет! 👋 Я твой AI фитнес-коуч. Спрашивай о питании, тренировках или мотивации!' },
  ]);
  const [input, setInput] = useState('');
  const [typing, setTyping] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, typing]);

  const sendMessage = async (text: string) => {
    if (!text.trim()) return;
    const userMsg: Message = { id: Date.now().toString(), role: 'user', text };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setTyping(true);

    try {
      const response = await api.askCoach({ message: text });
      setMessages(prev => [...prev, { id: (Date.now() + 1).toString(), role: 'coach', text: response.answer }]);
    } catch {
      setMessages(prev => [...prev, { id: (Date.now() + 1).toString(), role: 'coach', text: 'Не удалось получить ответ. Проверь backend и попробуй ещё раз.' }]);
    } finally {
      setTyping(false);
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-3.5rem)] lg:h-screen">
      <div className="p-4 border-b">
        <h1 className="text-lg font-bold flex items-center gap-2">
          <MessageCircle className="h-5 w-5 text-primary" /> AI Коуч
        </h1>
      </div>

      <div className="px-4 pt-3 flex gap-2 overflow-x-auto">
        {quickBtns.map((btn) => (
          <Button key={btn} variant="outline" className="rounded-full shrink-0" onClick={() => sendMessage(btn)}>
            {btn}
          </Button>
        ))}
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {messages.map(m => (
          <motion.div key={m.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[80%] rounded-2xl p-3 border ${m.role === 'user' ? 'bg-primary text-primary-foreground border-primary' : 'bg-card'}`}>
              <div className="flex items-center gap-2 mb-1 text-xs opacity-80">
                {m.role === 'user' ? <User className="h-3.5 w-3.5" /> : <Bot className="h-3.5 w-3.5" />}
                {m.role === 'user' ? 'Ты' : 'Коуч'}
              </div>
              <p className="text-sm whitespace-pre-wrap">{m.text}</p>
            </div>
          </motion.div>
        ))}
        {typing && <p className="text-sm text-muted-foreground">Коуч печатает...</p>}
        <div ref={bottomRef} />
      </div>

      <div className="p-4 border-t flex gap-2">
        <Input value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && sendMessage(input)} placeholder="Напиши вопрос..." className="rounded-xl" />
        <Button onClick={() => sendMessage(input)} className="rounded-xl gradient-primary text-primary-foreground">
          <Send className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}
