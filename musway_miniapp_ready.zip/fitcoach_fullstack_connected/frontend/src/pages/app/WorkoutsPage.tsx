import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Dumbbell, RefreshCw } from 'lucide-react';
import { motion } from 'framer-motion';
import { api } from '@/lib/api';
import { toast } from 'sonner';

export default function WorkoutsPage() {
  const [workout, setWorkout] = useState<string>('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    api.getLatestWorkout().then((data) => setWorkout(data.text || '')).catch(() => {});
  }, []);

  const generate = async () => {
    setLoading(true);
    try {
      const data = await api.generateWorkout();
      setWorkout(data.text);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Не удалось сгенерировать тренировку');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-4 md:p-8 max-w-2xl mx-auto space-y-6">
      <h1 className="text-2xl font-bold">Тренировки</h1>

      <Button onClick={generate} disabled={loading} className="w-full gradient-primary text-primary-foreground shadow-primary hover:opacity-90 h-12 rounded-xl text-base">
        {loading ? <><RefreshCw className="mr-2 h-4 w-4 animate-spin" />Генерация...</> : <><Dumbbell className="mr-2 h-4 w-4" />Сгенерировать тренировку</>}
      </Button>

      {!workout && !loading && (
        <div className="text-center py-16 text-muted-foreground">
          <Dumbbell className="h-12 w-12 mx-auto mb-4 opacity-30" />
          <p>Нажми кнопку, чтобы backend создал тренировку</p>
        </div>
      )}

      {!!workout && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-card rounded-2xl p-5 shadow-card border">
          <pre className="whitespace-pre-wrap text-sm leading-6">{workout}</pre>
        </motion.div>
      )}
    </div>
  );
}
