import { useEffect, useState } from 'react';
import { useAppContext } from '@/components/AppLayout';
import { calculateCalories } from '@/lib/mockData';
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, Tooltip } from 'recharts';
import { Link } from 'react-router-dom';
import { Plus, Dumbbell, Utensils, MessageCircle, Scale, Target, Flame, Activity } from 'lucide-react';
import { motion } from 'framer-motion';
import { api } from '@/lib/api';

export default function Dashboard() {
  const { profile, diary } = useAppContext();
  const [weightData, setWeightData] = useState<Array<{ day: string; weight: number }>>([]);
  const calorieGoal = calculateCalories(profile);
  const eaten = diary.reduce((s, e) => s + e.calories, 0);
  const remaining = calorieGoal - eaten;

  useEffect(() => {
    api.getWeightHistory()
      .then((items) =>
        setWeightData(
          items.map((x) => ({
            day: new Date(x.created_at).toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit' }),
            weight: x.weight,
          }))
        )
      )
      .catch(() => setWeightData([]));
  }, []);

  const stats = [
    { icon: Scale, label: 'Вес', value: `${profile.weight} кг`, sub: 'актуальный', color: 'text-primary' },
    { icon: Target, label: 'Цель веса', value: `${profile.targetWeight} кг`, sub: `осталось ${Math.max(profile.weight - profile.targetWeight, 0).toFixed(1)} кг`, color: 'text-primary' },
    { icon: Flame, label: 'Калории', value: `${eaten}`, sub: `из ${calorieGoal} | ост. ${remaining}`, color: 'text-primary' },
    { icon: Activity, label: 'Приемов пищи', value: `${diary.length}`, sub: 'сегодня', color: 'text-primary' },
  ];

  const quickActions = [
    { icon: Plus, label: 'Добавить еду', to: '/app/diary', color: 'gradient-primary text-primary-foreground' },
    { icon: Dumbbell, label: 'Тренировка', to: '/app/workouts', color: 'bg-foreground text-background' },
    { icon: Utensils, label: 'Питание', to: '/app/nutrition', color: 'bg-accent text-accent-foreground' },
    { icon: MessageCircle, label: 'Коуч', to: '/app/coach', color: 'bg-accent text-accent-foreground' },
  ];

  return (
    <div className="p-4 md:p-8 max-w-5xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl md:text-3xl font-bold">Привет, {profile.name}! 👋</h1>
        <p className="text-muted-foreground mt-1">Вот твоя сводка на сегодня</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
        {stats.map((item, i) => (
          <motion.div key={item.label} initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.06 }} className="bg-card rounded-2xl p-4 shadow-card border">
            <item.icon className={`h-5 w-5 mb-3 ${item.color}`} />
            <p className="text-xs text-muted-foreground">{item.label}</p>
            <p className="text-xl font-bold">{item.value}</p>
            <p className="text-xs text-muted-foreground mt-1">{item.sub}</p>
          </motion.div>
        ))}
      </div>

      <div className="grid lg:grid-cols-[1.2fr_0.8fr] gap-4">
        <div className="bg-card rounded-2xl p-5 shadow-card border">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold">Вес</h3>
          </div>
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={weightData}>
                <XAxis dataKey="day" tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 12 }} axisLine={false} tickLine={false} domain={['dataMin - 1', 'dataMax + 1']} />
                <Tooltip />
                <Line type="monotone" dataKey="weight" stroke="hsl(142, 71%, 45%)" strokeWidth={3} dot />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="space-y-4">
          <div className="bg-card rounded-2xl p-5 shadow-card border">
            <h3 className="font-semibold mb-4">Быстрые действия</h3>
            <div className="grid grid-cols-2 gap-3">
              {quickActions.map((action) => (
                <Link key={action.to} to={action.to} className={`${action.color} rounded-2xl p-4 min-h-24 flex flex-col justify-between`}>
                  <action.icon className="h-5 w-5" />
                  <span className="text-sm font-medium">{action.label}</span>
                </Link>
              ))}
            </div>
          </div>

          <div className="bg-card rounded-2xl p-5 shadow-card border">
            <h3 className="font-semibold mb-2">AI совет дня</h3>
            <p className="text-sm text-muted-foreground">
              Держи белок стабильным, а основной дефицит калорий оставь на ужин — так легче выдерживать режим.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
