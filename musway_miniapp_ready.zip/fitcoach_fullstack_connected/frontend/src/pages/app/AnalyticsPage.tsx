import { useEffect, useMemo, useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip, Line, ComposedChart } from 'recharts';
import { motion } from 'framer-motion';
import { api } from '@/lib/api';
import { useAppContext } from '@/components/AppLayout';

export default function AnalyticsPage() {
  const { diary, profile } = useAppContext();
  const [weekly, setWeekly] = useState<any>(null);

  useEffect(() => {
    api.weeklyAnalytics().then(setWeekly).catch(() => setWeekly(null));
  }, []);

  const chartData = useMemo(() => {
    const perTime = diary.map((item, i) => ({
      day: item.time || String(i + 1),
      calories: item.calories,
      goal: profile.targetWeight ? profile.weight : profile.weight,
    }));
    return perTime.length ? perTime : [{ day: 'Сегодня', calories: 0, goal: profile.weight }];
  }, [diary, profile]);

  return (
    <div className="p-4 md:p-8 max-w-2xl mx-auto space-y-6">
      <h1 className="text-2xl font-bold">Аналитика</h1>

      <div className="bg-card rounded-2xl p-5 shadow-card border">
        <h3 className="font-semibold mb-4">📊 Калории за сегодня</h3>
        <div className="h-56">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={chartData}>
              <XAxis dataKey="day" tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
              <Tooltip />
              <Bar dataKey="calories" fill="hsl(142, 71%, 45%)" radius={[6, 6, 0, 0]} name="Съедено" />
              <Line type="monotone" dataKey="goal" stroke="hsl(0, 0%, 70%)" strokeDasharray="5 5" strokeWidth={2} dot={false} name="Цель" />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="bg-card rounded-2xl p-5 shadow-card border">
        <h3 className="font-semibold mb-4">Среднее за неделю</h3>
        <div className="grid grid-cols-2 gap-4">
          {[
            { label: 'Калории', value: weekly?.avg_calories ?? 0, unit: '', goal: profile.weight },
            { label: 'Белки', value: weekly?.avg_protein ?? 0, unit: 'г', goal: 120 },
            { label: 'Жиры', value: weekly?.avg_fat ?? 0, unit: 'г', goal: 70 },
            { label: 'Углеводы', value: weekly?.avg_carbs ?? 0, unit: 'г', goal: 220 },
          ].map((item) => (
            <div key={item.label} className="bg-muted/50 rounded-xl p-3">
              <p className="text-xs text-muted-foreground">{item.label}</p>
              <p className="text-xl font-bold">{item.value}{item.unit}</p>
              <p className="text-xs text-primary">цель: {item.goal}</p>
            </div>
          ))}
        </div>
      </div>

      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="bg-accent rounded-2xl p-5 text-accent-foreground">
        <h3 className="font-semibold mb-2">💡 Инсайт</h3>
        <p className="text-sm">{weekly?.message || 'Добавь больше записей в дневник, и аналитика станет полезнее.'}</p>
      </motion.div>
    </div>
  );
}
